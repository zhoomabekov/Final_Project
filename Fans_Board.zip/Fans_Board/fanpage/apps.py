from django.apps import AppConfig


class FanpageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fanpage'
    
    def ready(self):
        import fanpage.signals
